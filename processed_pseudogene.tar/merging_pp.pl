use strict;
use Data::Dumper;

my @data= ();
my $infile = shift;
open IN, "<$infile" or die $!;
while(my $row = <IN>)
{
	my @array = split /\s+/, $row;
	push @data, \@array;
}
close IN;

my $cursor=0;
my $left = $data[$cursor]->[0];
my $right = $data[$cursor]->[1];
my @done=();
push @done, $cursor;
while(1)
{
	my $n=0;
	for(my $i=$cursor+1; $i<scalar @data; $i++)
	{
		if(&overlap($left, $right, $data[$i]->[0], $data[$i]->[1]))
		{
			if($data[$i]->[0]<$left){$left=$data[$i]->[0];}	
			if($data[$i]->[1]>$right){$right=$data[$i]->[1];}
			$n++;
			push @done, $i;
		}
	}
	my $width = $right-$left;
	print $left." ".$right." ".$width." ".$n."\n";

	my $next=-1;
	for(my $i=0; $i<scalar @data; $i++)
	{
		if(!&contain(\@done, $i)){$next=$i;last;}
	}
	if($next==-1){last;}
	$cursor=$next;
	$n=0;
	$left=$data[$cursor]->[0];
	$right = $data[$cursor]->[1];
	push @done, $cursor;
}
sub contain($$)
{
	my $array = shift;
	my $x = shift;
	for(my $i=0; $i<scalar @$array; $i++)
	{
		if($array->[$i] eq $x){return 1;}
	}
	return 0;
}
sub overlap($$$$)
{
        my $e1 = shift;
        my $e2 = shift;
        my $x1 = shift;
        my $x2 = shift;
        if(($x1>=$e1 && $x1<=$e2)||
            ($x2>=$e1 && $x2<=$e2) ||
            ($x1<=$e1 && $x2>=$e2)
           ){return 1;}
        return 0;
}

