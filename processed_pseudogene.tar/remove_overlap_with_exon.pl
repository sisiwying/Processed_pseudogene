use strict;
use Data::Dumper;

my $chr=shift;
my $infile = shift;
my @data=();
open IN, "<XENLA_9.2_Xenbase.gff3" or die $!;
while(my $row=<IN>)
{
	if($row!~"^#")
	{
        	my @array = split /\s+/, $row;
		if($array[0] eq $chr)
		{
        		push @data, \@array;
		}
	}
}
close IN;

my @gene=();
for(my $i=0; $i<scalar @data; $i++)
{
	if($data[$i]->[2] eq "gene")
	{
		if($data[$i]->[8] =~ /ID=(.*?);/)
		{ push @gene, $1;}
	}
}

my @trans=();
for(my $g=0; $g<scalar @gene; $g++)
{
	for(my $i=0; $i<scalar @data; $i++)
	{
		if($data[$i]->[8] =~ /Parent=$gene[$g];/)
		{
			if($data[$i]->[8]=~/ID=(.*?);/){push @trans, $1;}
		}
	}
}

my @exons=();
for(my $j=0; $j<scalar @data; $j++)
{
	if($data[$j]->[2] eq "exon")
	{
		my $tr;
		if($data[$j]->[8]=~/Parent=(.*?);/){$tr=$1;}
		if(&contain(\@trans, $tr))
		{
			my @one=();
			push @one, $data[$j]->[3];	
			push @one, $data[$j]->[4]; 
			push @exons, \@one;
		}
	}
}

open IN, "<$infile" or die $!;
while(my $row = <IN>)
{
        my @array = split /\s+/, $row;
	if(!&overlap(\@exons, $array[0], $array[1]))		
	{
		print $row;
	}
}
close IN;

sub contain($$)
{
	my $array = shift;
	my $x = shift;
	for(my $i=0; $i<scalar @$array; $i++)
	{
		if($array->[$i] eq $x){return 1;}
	}
	return 0;
}

sub overlap($$$)
{
	my $exons = shift;
	my $x1 = shift;
	my $x2 = shift;
	for(my $i=0; $i<scalar @$exons; $i++)
	{
		if(($x1>=$exons->[$i]->[0] && $x1<=$exons->[$i]->[1])||
		    ($x2>=$exons->[$i]->[0] && $x2<=$exons->[$i]->[1]) ||
		    ($x1<=$exons->[$i]->[0] && $x2>=$exons->[$i]->[1])	
			){return 1;}
	}
	return 0;
}
