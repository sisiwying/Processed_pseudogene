use strict;

my $infile = shift;

my @pg=();
open IN, "<Homo_sapiens.GRCh38.95.chromosome.3.gff3" or die $!;
while(my $row = <IN>)
{
	if($row !~"^#")
	{
		my @array = split /\s+/, $row;
		#if($array[2] eq "pseudogene" && $array[8]=~"biotype=transcribed_unprocessed_pseudogene;")
		if($array[2] eq "pseudogene" ) #&& $array[8]=~/biotype=processed_pseudogene;/)	
		 # if( $array[2] eq "ncRNA_gene") 
		 # $array[2] eq "ncRNA" || $array[2] eq "miRNA" || $array[2] eq "snRNA" || $array[2] eq "snoRNA"	
		 #  $array[2] eq "gene")
		{
			my @one=();
			push @one, $array[3];
			push @one, $array[4];
			push @pg, \@one;
		}
	}
}
close IN;
print scalar @pg."\n";

my @data = ();
open IN, "<$infile" or die $!;
while(my $row = <IN>)
{
	my @array = split /\s+/, $row;
	push @data, \@array;
}
close IN;

my $c=1;
my $op=0;
for(my $i=0; $i<scalar @data; $i++)
{
	my $real=0;
	for(my $j=0; $j<scalar @pg; $j++)
	{
		if(&overlap($data[$i]->[0], $data[$i]->[1], $pg[$j]->[0], $pg[$j]->[1])){$op++;$real=1; last;}
	}
	my $width = $data[$i]->[1]-$data[$i]->[0];
	print $data[$i]->[0]." ".$data[$i]->[1]." ".$width." ".$real."\n";	
	$c++;
}
print $op." out of ".scalar @data."\n";

$op=0;
for(my $i=0; $i<scalar @pg; $i++)
{
        my $real=0;
        for(my $j=0; $j<scalar @data; $j++)
        {
                if(&overlap($data[$j]->[0], $data[$j]->[1], $pg[$i]->[0], $pg[$i]->[1])){$op++; last;}
        }
}
print $op." out of ".scalar @pg."\n";


sub overlap($$$$)
{
        my $e1 = shift;
	my $e2 = shift;
        my $x1 = shift;
        my $x2 = shift;
        if(($x1>=$e1 && $x1<=$e2)||
            ($x2>=$e1 && $x2<=$e2) ||
            ($x1<=$e1 && $x2>=$e2)
           ){return 1;}
        return 0;
}

