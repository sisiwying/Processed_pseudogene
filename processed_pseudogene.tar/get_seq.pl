use strict;
use Data::Dumper;

my @data=();
open IN, "<results_seg1_sum_3_seq.fa" or die $!;
while(my $row = <IN>)
{
	chomp($row);
	my $row2 = <IN>;
	chomp($row2);
	my $name;
	if($row=~/^>(.*)/)
	{
		$name = $1;
	}
	my @one=();
	push @one, $name;
	push @one, $row2;
	push @data, \@one;
}
close IN;

my @protein=();
open IN, "<uniprot_format.fa" or die $!;
while(my $row = <IN>)
{
	my $row2 = <IN>;
	chomp($row);
	chomp($row2);
	
	my @one=();
	if($row=~/^>(.*)/){push @one, $1;}
	push @one, $row2;
	push @protein, \@one;
}
close IN;
my $c=1;
open IN, "<results_seg1_sum_5.out" or die $!;
while(my $row = <IN>)
{
	my @array = split /\s+/, $row;
	my $name = $array[0]." ".$array[1]." ".$array[2];
	open OUT, ">file$c.fasta" or die $!;
	for(my $i=0; $i<scalar @data; $i++)
	{
		if($name eq $data[$i]->[0])
		{
			print OUT ">$name"."\n";
			print OUT $data[$i]->[1]."\n";
			last;
		}
	}
	close OUT;

	print $array[2]."\n";
	open OUT, ">protein$c.fasta" or die $!;
	for(my $i=0; $i<scalar @protein; $i++)
	{
		if($array[2] eq $protein[$i]->[0])
		{
			print OUT ">".$array[2]."\n";	
			print OUT $protein[$i]->[1]."\n";
			last;
		}
	}
	close OUT;
	$c++;
}
close IN;


