use strict;

my $count=0;
for(my $i=1; $i<=18; $i++)
{
	my $chr;
	if($i==1) {$chr="1L";}
	elsif($i==2) {$chr="1S";}
	elsif($i==3) {$chr="2L";}
	elsif($i==4) {$chr="2S";}
	elsif($i==5) {$chr="3L";}
	elsif($i==6) {$chr="3S";}
	elsif($i==7) {$chr="4L";}
	elsif($i==8) {$chr="4S";}
	elsif($i==9) {$chr="5L";}
	elsif($i==10) {$chr="5S";}
	elsif($i==11) {$chr="6L";}
	elsif($i==12) {$chr="6S";}
	elsif($i==13) {$chr="7L";}
	elsif($i==14) {$chr="7S";}
	elsif($i==15) {$chr="8L";}
	elsif($i==16) {$chr="8S";}
	elsif($i==17) {$chr="9_10L";}
	elsif($i==18) {$chr="9_10S";}

	open IN, "<results2_chr$chr" or die $!;
	while(my $row = <IN>)
	{
		my @array = split /\s+/, $row;

		print $array[0];
		print "\t".".";
		print "\t"."Processed_pseudogene";
		print "\t".$array[1];
		print "\t".$array[2];
		print "\t"."."."\t"."."."\t".".";
		print "\t"."name=pp_$count"."\n";
		$count++;
	}
	close IN;
}
