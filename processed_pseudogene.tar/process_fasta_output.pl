use strict;

my $infile = shift;
my $pr_len;
open IN, "<$infile" or die $!;
while(my $row = <IN>)
{
	if($row =~ />>>.*\s-\s(.*)\saa/)
	{$pr_len = $1;}

	if($row=~/^>/)
	{
		my $row2 = <IN>;
		my $row3 = <IN>;
		my $e; my $i; my $overlap; my $frame; my $lb; my $rb;
		if($row2=~/Frame:\s(.*)\sinitn.*E\(.*\):\s(.*)\n/){$frame=$1; $e = $2;}
		if($row3 =~ /;\s(.*)% identity.*in\s(.*)\saa overlap\s\(.*:(.*)-(.*)\)/) 
		{$i = $1; $overlap=$2; $lb=$3; $rb=$4;}

		if($e<1e-20 && $i>40 && $overlap/$pr_len>0.70) 
		{
			if($row=~/>>(.*?)\s/)
			{
				my $r1 = $1+$lb;
				my $r2 = $1+$rb;
				if($r1<$r2)	{print $r1." ".$r2."\n";}
				else {print $r2." ".$r1."\n";}
			}
		}
	}
}
close IN;
