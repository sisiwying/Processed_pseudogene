use strict;

my $infile = shift;
my @gene=();
open IN, "<Homo_sapiens.GRCh38.95.chromosome.10.gff3" or die $!;
while(my $row = <IN>)
{
	if($row=~/^#/){next;}
	my @array = split /\s+/, $row;
	if($array[2] eq "gene")
	{
		my @one=();
		push @one, $array[3];
		push @one, $array[4];
		push @gene, \@one;
	}
}
close IN;

open IN, "<$infile" or die $!;
while(my $row=<IN>)
{
	my @array = split /\s+/, $row;

	my $op=0;
	for(my $i=0; $i<scalar @gene; $i++)
	{
		if(&overlap($array[0], $array[1], $gene[$i]->[0], $gene[$i]->[1])){$op=1; last;}
	}
	if($op==0)
	{
		print $row;
	}
}
close IN;

sub overlap($$$$)
{
        my $e1 = shift;
        my $e2 = shift;
        my $x1 = shift;
        my $x2 = shift;
        if(($x1>=$e1 && $x1<=$e2)||
            ($x2>=$e1 && $x2<=$e2) ||
            ($x1<=$e1 && $x2>=$e2)
           ){return 1;}
        return 0;
}

