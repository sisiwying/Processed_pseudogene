use strict;
use Data::Dumper;

for(my $i=0; $i<=20; $i++)
{
	my $start = 5000000*$i;
	my $file = "results_seg$i"."_sum_6.out";

	open IN, "<chr9_10S/$file" or die $!;
	while(my $row = <IN>)
	{
		my @array = split /\s+/, $row;
		my $width = $array[1]-$array[0];
		my $s = $array[0]+$start;
		my $e = $array[1]+$start;	
		print $s." ".$e." ".$width."\n";
	}	
}
close IN;


