use strict;
use Data::Dumper;

my $infile = shift;
my $ofile =  shift;
my $seg = shift;

my @data=();
open IN, "<uniprot_format.fa" or die $!;
while(my $row = <IN>)
{
	my $row2 = <IN>;
	chomp($row2);
	
	my @array;
	if($row=~/>(.*)/)
        {
                @array = split /\s+/, $1;
        }
	my @one=();
	push @one, $array[0];
	push @one, $row2;
	push @data, \@one;
}

open IN, "<$infile" or die $!;
while(my $row = <IN>)
{
	open SEQ, ">seq_$seg.fa" or die $!;
	open PR, ">protein_$seg.fa" or die $!;

	my $row2 = <IN>;

	my @array;
	if($row=~/>(.*)/)
	{
		@array = split /\s+/, $1;
	}
	print SEQ $row;
	print SEQ $row2;

	for(my $i=0; $i<scalar @data; $i++)
	{
		if($data[$i]->[0] eq $array[2])
		{
			print PR ">".$data[$i]->[0]."\n";
			print PR $data[$i]->[1]."\n";
		}
	}
	close SEQ;
	close PR;

	system "./program/fasta-36.3.8g/bin/tfastx36 protein_$seg.fa seq_$seg.fa >>  $ofile";
}
close IN;
