use strict;

my $chr= shift;
open IN, "<xenLae2.fa.masked" or die $!;
while(my $row = <IN>)
{
	if($row=~/^>$chr/)
	{
		print $row;
		while($row = <IN>)
		{
			if($row=~/^>/){last;}
			print $row;
		}
	}
}
close IN;
