use strict;

open IN, "<uniprot_organism__Xenopus_laevis.fasta" or die $!;
my @infor=();
my @seq=();
my $pr;
my $row = <IN>;
if($row=~/^>(.*?)\s/)
{
	@seq=();
	$pr = $1;
}
while(my $row = <IN>)
{
	if($row=~/^>(.*?)\s/)
	{
		my @one=();
		push @one, $pr;
		push @one, scalar @seq;
		push @infor, \@one;
		@seq=();	
		$pr=$1;
	}
	else
	{
		chomp($row);
		my @array = split //, $row;
		for(my $i=0; $i<scalar @array; $i++)
		{
			push @seq, $array[$i];
		}
	}
}
my @one=();
push @one, $pr;
push @one, scalar @seq;
push @infor, \@one;
close IN;

for(my $i=0; $i<scalar @infor; $i++)
{
	print $infor[$i]->[0]." ".$infor[$i]->[1]."\n";
}
