use strict;

my @seq=();
open IN, "<databases/xenLae2_masked_chr9_10S.fa" or die $!;
my $row = <IN>;
while($row = <IN>)
{
	chomp($row);
	my @array = split //, $row;
	for(my $i=0; $i<scalar @array; $i++)
	{
		push @seq, $array[$i];
	}
}
close IN;
print scalar @seq."\n";

my $seg=1;
my $start; my $end;
for(my $i=0; $i<21; $i++)
{
	if($i==0){$start=0;}
	else{$start = $end-100000;}
	
	if($i<=19) {$end=$start+5100000;}
	else {$end=scalar @seq;}

	print $start." ".$end."\n";
	
	my $file = "chr9_10S_"."seg_".$i.".fa";
	open OUT, ">$file" or die $!;
	print OUT ">chr9_10S_".$start."_".$end."\n";
	for(my $j=$start; $j<$end; $j++)
	{
		print OUT $seq[$j];
	}
	print OUT "\n";
	close OUT;
}
