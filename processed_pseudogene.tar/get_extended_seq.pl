use strict;

my $startp=shift;
my $infile1 = shift;
my $infile = shift;

open IN, "<$infile1" or die $!;
my $row = <IN>;
$row=<IN>;
chomp($row);
my @seq =split //, $row;
close IN;

my @pr_length=();
open IN, "<protein_length.txt" or die $!;
while(my $row = <IN>)
{
	my @array = split /\s+/, $row;
	push @pr_length, \@array;
}
close IN;

open IN, "<$infile" or die $!;
while(my $row = <IN>)
{
	my @array = split /\s+/, $row;
	my $len=-1;
	for(my $i=0; $i<scalar @pr_length; $i++)
	{
		if($pr_length[$i]->[0] eq $array[2]){$len=$pr_length[$i]->[1]; last;}
	}
	my $mid = int($array[0]+($array[1]-$array[0])*0.5);
	my $left = int($mid-$len*3*0.5-30)-$startp;
	my $right = int($mid+$len*3*0.5+30)-$startp;

	if($right>scalar @seq-1){$right=scalar @seq-1;}

	print ">".$left." ".$right." ".$array[2]."\n";	
	for(my $i=$left; $i<$right; $i++)
	{
		print $seq[$i];
	}
	print "\n";
}
close IN;
