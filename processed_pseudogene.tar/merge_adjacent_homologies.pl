use strict;
use Data::Dumper;

my $infile = shift;
my @pr_length=();
open IN, "<protein_length.txt" or die $!;
while(my $row = <IN>)
{
	my @array = split /\s+/, $row;
	push @pr_length, \@array;
}	
close IN;

my @data=();
my @proteins=();
open IN, "<$infile" or die $!;
while(my $row = <IN>)
{
	my @array = split /\s+/, $row;
	push @data, \@array;
	if(!&contain(\@proteins, $array[2])){push @proteins, $array[2];}
}
close IN;

for(my $i=0; $i<scalar @proteins; $i++)
{
	my @segs=();
	for(my $j=0; $j<scalar @data; $j++)
	{
		if($data[$j]->[2] eq $proteins[$i])
		{
			push @segs, $data[$j];
		}
	}	

	my @segs_sort = sort {$a->[0]<=>$b->[0]} @segs;

	my @merge=();
	for(my $j=0; $j<scalar @segs_sort-1; $j++)
	{
		my $c11 = $segs_sort[$j]->[0];
		my $c12 = $segs_sort[$j]->[1];
		my $c21 = $segs_sort[$j+1]->[0];
		my $c22 = $segs_sort[$j+1]->[1];
		my $q11 = $segs_sort[$j]->[3];
		my $q12 = $segs_sort[$j]->[4];
		my $q21 = $segs_sort[$j+1]->[3];
		my $q22 = $segs_sort[$j+1]->[4];
	
		my $L;
		for(my $k=0; $k<scalar @pr_length; $k++)
		{
			if($pr_length[$k]->[0] eq $segs_sort[$j]->[2]){$L=$pr_length[$k]->[1]; last;}
		}	

		my $m;
		if(20> 0.2*$L){$m=20}
		else {$m=0.2*$L;}

		if($q21-$q12<=$m && $c21-$c12<=5000 && $c22-$c21<=60)
		{
			push @merge, $j;	
			push @merge, $j+1;
		}
	}

	my @new_seg=();	
	if(scalar @merge>0)
	{
		my $start = 0;
		my $end = $start+1;
		while(1)
		{
			while($end<=scalar @merge-2 && $merge[$end+1]==$merge[$end]){$end+=2; if($end==scalar @merge-1){last;}}	

			my @one=();
			push @one, $segs_sort[$merge[$start]]->[0];
			push @one, $segs_sort[$merge[$end]]->[1];
			push @one, $segs_sort[$merge[$start]]->[2];
			push @new_seg, \@one;

			$start = $end+1;
			$end = $start+1;
			if($end > scalar @merge-1){last;}
		}
	}

	for(my $j=0; $j<scalar @segs_sort; $j++)
        {
            if(!&contain(\@merge, $j)){push @new_seg, $segs_sort[$j];}
        }

	my @new_seg_sort = sort {$a->[0]<=>$b->[0]} @new_seg;
	for(my $j=0; $j<scalar @new_seg_sort; $j++)
	{
		print $new_seg_sort[$j]->[0]." ".$new_seg_sort[$j]->[1]." ".$new_seg_sort[$j]->[2]."\n";
	}
}


sub contain($$)
{
        my $array = shift;
        my $x = shift;
        for(my $i=0; $i<scalar @$array; $i++)
        {
                if($array->[$i] eq $x){return 1;}
        }
        return 0;
}

