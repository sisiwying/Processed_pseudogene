use strict;

my $infile=shift;
open IN, "<$infile" or die $!;
while(my $row = <IN>)
{
	if($row!~"^#")
	{
		my @array = split /\s+/, $row;
		my $start;
		if($array[1]=~/(.*)_(.*)_(.*)/) {$start=$2;}
		my $loc1=$array[8]+$start;
		my $loc2=$array[9]+$start;

		if($loc1<$loc2)
		{
			print $loc1." ".$loc2." ".$array[0]." ".$array[6]." ".$array[7]."\n";
		}
		else
		{
			print $loc2." ".$loc1." ".$array[0]." ".$array[6]." ".$array[7]."\n";
		}
	}
}
close IN;
