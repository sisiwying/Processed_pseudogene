use strict;

for(my $i=0; $i<=20; $i++)
{
	#system "makeblastdb -in databases/chr9_10S/chr9_10S_seg_$i.fa -parse_seqids -dbtype nucl";

	#my $ofile = "chr9_10S/results_seg$i"."_sum.out";
	#system "perl -w summarize_tblastn_output.pl chr9_10S/results_seg$i.out > $ofile";

	#my $infile = "chr9_10S/results_seg$i"."_sum.out";
	#my $ofile = "chr9_10S/results_seg$i"."_sum_2.out";	
	#system "perl -w remove_overlap_with_exon.pl chr9_10S $infile > $ofile";

	#my $infile = "chr9_10S/results_seg$i"."_sum_2.out";
	#my $ofile = "chr9_10S/results_seg$i"."_sum_3.out";	
	#system "perl -w merge_adjacent_homologies.pl $infile > $ofile";
	
	#my $startp = 5000000 * $i;
	#my $infile1 = "databases/chr9_10S/chr9_10S_seg_$i.fa";
	#my $infile2 = "chr9_10S/results_seg$i"."_sum_3.out";
	#my $ofile = "chr9_10S/results_seg$i"."_sum_3_seq.fa";

	#system "perl -w get_extended_seq.pl $startp $infile1 $infile2 > $ofile"; 

	#my $infile = "chr9_10S/results_seg$i"."_sum_4.out";	
	#my $ofile = "chr9_10S/results_seg$i"."_sum_5.out";
	#system "perl -w process_fasta_output.pl $infile > $ofile"; 

	my $infile = "chr9_10S/results_seg$i"."_sum_5.out";
	my $ofile = "chr9_10S/results_seg$i"."_sum_6.out";
	system "perl -w merging_PP.pl $infile > $ofile"; 
}
