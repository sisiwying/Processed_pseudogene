use strict;

open IN, "<Trop91_processed_pseudogene.gff3" or die $!;
while(my $row = <IN>)
{
	my @array = split /\s+/, $row;
	if($array[8]=~/name=(.*)/)	
	{
		print $1."\t".$array[0]."\t".$array[3]."\t".$array[4]."\n";
	}
}
close IN;
