use strict;

my @pg=();
open IN, "<Homo_sapiens.GRCh38.95.chromosome.10.gff3" or die $!;
while(my $row = <IN>)
{
        if($row !~"^#")
        {
                my @array = split /\s+/, $row;
                if($array[2] eq "pseudogene" && $array[8]=~"biotype=processed_pseudogene")
                {
                        my @one=();
                        push @one, $array[3];
                        push @one, $array[4];
                        push @pg, \@one;
                }
        }
}
close IN;
print scalar @pg."\n";

my $min_len=-1; 
for(my $i=0; $i<scalar @pg; $i++)
{
	if($min_len==-1 || $min_len>$pg[$i]->[1]-$pg[$i]->[0])	
	{
		$min_len=$pg[$i]->[1]-$pg[$i]->[0];
	}
}
print $min_len."\n";
