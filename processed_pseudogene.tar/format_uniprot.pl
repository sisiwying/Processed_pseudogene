use strict;

open IN, "<uniprot_organism__Xenopus_laevis.fasta" or die $!;
my @infor=();
my @seq=();
my $pr;
my $row = <IN>;
if($row=~/^>(.*?)\s/)
{
        @seq=();
        $pr = $1;
}
while(my $row = <IN>)
{
        if($row=~/^>(.*?)\s/)
        {
                my @one=();
                print ">".$pr."\n";
		for(my $i=0; $i<scalar @seq; $i++)
		{print $seq[$i];}
		print "\n";
                @seq=();
                $pr=$1;
        }
        else
        {
                chomp($row);
                my @array = split //, $row;
                for(my $i=0; $i<scalar @array; $i++)
                {
                        push @seq, $array[$i];
                }
        }
}
print ">".$pr."\n";
for(my $i=0; $i<scalar @seq; $i++)
{print $seq[$i];}
print "\n";

close IN;

